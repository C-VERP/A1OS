import logging
import requests
from odoo import models, fields, api

_logger = logging.getLogger(__name__)

class HelpdeskTicket(models.Model):
    _inherit = 'helpdesk.ticket'

    bol_question_id = fields.Char("Bol.com Vraag ID")

class BolHelpdeskTicketImporter(models.Model):
    _name = 'bol.helpdesk.ticket.importer'
    _description = 'Importeer en verzend Bol.com vragen en antwoorden'

    def _get_access_token(self):
        config = self.env['ir.config_parameter'].sudo()
        client_id = config.get_param('bol.client_id')
        client_secret = config.get_param('bol.client_secret')
        if not client_id or not client_secret:
            _logger.error("Client ID of Secret niet ingesteld.")
            return None

        token_url = "https://login.bol.com/token"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        }

        response = requests.post(token_url, headers=headers, data=data)
        if response.status_code == 200:
            return response.json().get("access_token")
        else:
            _logger.error("Kan geen access token ophalen: %s", response.content)
            return None

    @api.model
    def import_bol_tickets(self):
        token = self._get_access_token()
        if not token:
            return

        bol_api_url = "https://api.bol.com/retailer/customer-questions"
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json"
        }

        response = requests.get(bol_api_url, headers=headers)
        if response.status_code == 200:
            questions = response.json().get('questions', [])
            for q in questions:
                if not self.env['helpdesk.ticket'].search([('bol_question_id', '=', q['id'])]):
                    self.env['helpdesk.ticket'].create({
                        'name': q.get('subject', 'Vraag via Bol.com'),
                        'description': q.get('question', ''),
                        'partner_email': q.get('customerEmail', ''),
                        'bol_question_id': q.get('id'),
                        'team_id': self.env.ref('helpdesk.team1').id,
                    })
        else:
            _logger.warning("Fout bij ophalen van BOL vragen: %s", response.content)

    def send_response_to_bol(self, ticket, message_body):
        token = self._get_access_token()
        if not token or not ticket.bol_question_id:
            return

        bol_api_url = f"https://api.bol.com/retailer/customer-questions/{ticket.bol_question_id}/response"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        payload = {"response": message_body}
        response = requests.post(bol_api_url, json=payload, headers=headers)
        if response.status_code != 200:
            _logger.error("Fout bij verzenden naar Bol.com: %s", response.content)
