from odoo import http
from odoo.http import request

class BolWebhookController(http.Controller):

    @http.route('/bol/webhook/question', auth='public', type='json', csrf=False)
    def receive_question(self, **post):
        question = post.get("question")
        if question:
            request.env['helpdesk.ticket'].sudo().create({
                'name': question.get('subject', 'Vraag via Bol'),
                'description': question.get('question', ''),
                'partner_email': question.get('customerEmail', ''),
                'bol_question_id': question.get('id'),
                'team_id': request.env.ref('helpdesk.team1').id,
            })
        return {"status": "ok"}
