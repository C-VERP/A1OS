{
    "name": "Bol.com Partner Helpdesk Integratie",
    "version": "1.1",
    "depends": ["helpdesk"],
    "author": "Jouw Naam",
    "category": "Helpdesk",
    "description": "Importeert klantvragen van Bol.com partners als helpdesktickets en verzendt antwoorden terug.",
    "data": [
        "data/ir_cron.xml",
        "views/res_config_settings_views.xml"
    ],
    "installable": True,
    "application": False,
}
