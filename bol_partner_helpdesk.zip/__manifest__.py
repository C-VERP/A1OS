{
    "name": "Bol.com Partner Helpdesk Integratie",
    "version": "1.0",
    "depends": ["helpdesk"],
    "author": "Jouw Naam",
    "category": "Helpdesk",
    "description": "Importeert klantvragen van Bol.com partners als helpdesktickets en verzendt antwoorden terug.",
    "data": [
        "data/ir_cron.xml"
    ],
    "installable": True,
    "application": False
}
