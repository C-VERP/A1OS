import logging
import requests
from odoo import models, fields, api

_logger = logging.getLogger(__name__)

class HelpdeskTicket(models.Model):
    _inherit = 'helpdesk.ticket'

    bol_question_id = fields.Char("Bol.com Vraag ID")

class BolHelpdeskTicketImporter(models.Model):
    _name = 'bol.helpdesk.ticket.importer'
    _description = 'Importeer en verzend Bol.com vragen en antwoorden'

    @api.model
    def import_bol_tickets(self):
        bol_api_url = "https://api.bol.com/retailer/customer-questions"
        headers = {
            "Authorization": "Bearer YOUR_API_TOKEN",
            "Accept": "application/json"
        }

        response = requests.get(bol_api_url, headers=headers)
        if response.status_code == 200:
            questions = response.json().get('questions', [])
            for q in questions:
                if not self.env['helpdesk.ticket'].search([('bol_question_id', '=', q['id'])]):
                    self.env['helpdesk.ticket'].create({
                        'name': q.get('subject', 'Vraag via Bol.com'),
                        'description': q.get('question', ''),
                        'partner_email': q.get('customerEmail', ''),
                        'bol_question_id': q.get('id'),
                        'team_id': self.env.ref('helpdesk.team1').id,
                    })
        else:
            _logger.warning("Fout bij ophalen van BOL vragen: %s", response.content)

    def send_response_to_bol(self, ticket, message_body):
        if not ticket.bol_question_id:
            return

        bol_api_url = f"https://api.bol.com/retailer/customer-questions/{ticket.bol_question_id}/response"
        headers = {
            "Authorization": "Bearer YOUR_API_TOKEN",
            "Content-Type": "application/json"
        }
        payload = {"response": message_body}
        response = requests.post(bol_api_url, json=payload, headers=headers)
        if response.status_code != 200:
            _logger.error("Fout bij verzenden naar Bol.com: %s", response.content)
