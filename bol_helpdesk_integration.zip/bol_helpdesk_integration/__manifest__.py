{
    "name": "Bol.com Helpdesk Integratie",
    "version": "1.0",
    "summary": "Importeer bol.com klantvragen als helpdesk tickets",
    "category": "Helpdesk",
    "author": "ChatGPT",
    "depends": ["helpdesk"],
    "data": [],
    "installable": True,
    "application": False,
    "auto_install": False
}
