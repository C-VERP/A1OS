{
    "name": "Bol.com Helpdesk Integratie",
    "version": "1.0",
    "summary": "Importeer bol.com klantvragen als helpdesk tickets",
    "category": "Helpdesk",
    "author": "ChatGPT",
    "depends": ["helpdesk"],
    "data": ["bol_settings_view.xml", "cron.xml"],
    "installable": True,
    "application": False,
    "auto_install": False
}
