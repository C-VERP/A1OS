from odoo import models, fields

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    bol_client_id = fields.Char(string="Bol.com Client ID", config_parameter='bol.client_id')
    bol_client_secret = fields.Char(string="Bol.com Client Secret", config_parameter='bol.client_secret')
    bol_environment = fields.Selection([('prod', 'Productie'), ('sandbox', 'Sandbox')],
                                       string="Bol.com omgeving", default='sandbox',
                                       config_parameter='bol.environment')