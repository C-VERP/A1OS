{
    "name": "Bol.com Helpdesk Sync",
    "version": "1.0",
    "category": "Helpdesk",
    "summary": "Importeert klantvragen van bol.com als tickets in Odoo Helpdesk",
    "depends": ["helpdesk"],
    "data": [
        "views/bol_config_settings_views.xml",
    ],
    "assets": {},
    "installable": True,
    "application": False,
}